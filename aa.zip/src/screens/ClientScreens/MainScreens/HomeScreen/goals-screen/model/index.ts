export * from "./goals-details-client-model";
