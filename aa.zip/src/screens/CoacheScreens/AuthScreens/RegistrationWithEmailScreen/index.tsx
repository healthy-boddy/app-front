export {default as EmailRegistration} from './EmailRegistration'
