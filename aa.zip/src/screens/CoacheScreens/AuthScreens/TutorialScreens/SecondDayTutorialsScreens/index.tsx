export {default as SecondFirstTutorialScreen} from './SecondFirstTutorialScreen'
export {default as SecondTwoTutorialScreen} from './SecondTwoTutorialScreen'
export {default as SecondThirdTutorialScreen} from './SecondThirdTutorialScreen'
export {default as TyScreenFromSecondDay} from './TyScreenFromSecondDay'
