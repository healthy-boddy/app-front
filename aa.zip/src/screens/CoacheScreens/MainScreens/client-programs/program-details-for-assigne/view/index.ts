export * from "./program-details-for-assign-view";
