export * from "./program-details-view";
