require('ts-node/register');
module.exports = require('./webpack.config.ts');
