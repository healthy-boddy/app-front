export {default as PaidQuizzesScreen} from './PaidQuizzesScreen'
export {default as TyScreen} from './TyScreen'
