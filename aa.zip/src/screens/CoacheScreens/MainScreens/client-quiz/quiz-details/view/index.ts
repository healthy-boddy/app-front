export * from "./client-takts-view";
