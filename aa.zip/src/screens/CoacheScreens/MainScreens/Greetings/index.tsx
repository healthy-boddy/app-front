export {default as GreetingsScreen6} from './GreetingsScreen6'
export {default as GreetingsScreen7} from './GreetingsScreen7'
