export {default as GreetingsScreen} from './GreetingsScreen'
export {default as GreetingsScreen2} from './GreetingsScreen2'
export {default as GreetingsScreen3} from './GreetingsScreen3'
export {default as GreetingsScreen4} from './GreetingsScreen4'
export {default as GreetingsScreen5} from './GreetingsScreen5'

