export * from "./program-details-client-view";
