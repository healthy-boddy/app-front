export * from "./global-goals-editing-model";
