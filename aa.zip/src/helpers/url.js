export const baseUrl = 'http://92.53.97.238/user'
export const baseUrl2 = 'http://92.53.97.238'
