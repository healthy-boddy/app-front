export const color1 = '#7454CF'
export const color2 = '#e0dddd'
export const color3 = '#797979'
