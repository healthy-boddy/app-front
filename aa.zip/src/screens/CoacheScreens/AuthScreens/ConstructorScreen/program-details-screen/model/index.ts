export * from "./program-details-model";
