export * from "./program-details-for-assign-model";
